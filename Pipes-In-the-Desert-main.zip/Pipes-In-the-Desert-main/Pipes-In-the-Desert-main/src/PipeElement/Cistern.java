package PipeElement;

public class Cistern extends ActiveElement {

    public Cistern()
    {
        super("cistern");
    }
}
