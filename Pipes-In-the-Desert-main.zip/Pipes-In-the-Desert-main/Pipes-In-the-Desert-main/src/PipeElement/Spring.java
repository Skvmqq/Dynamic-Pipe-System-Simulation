package PipeElement;

public class Spring extends ActiveElement {

    public Spring()
    {
        super("spring");
    }
}
